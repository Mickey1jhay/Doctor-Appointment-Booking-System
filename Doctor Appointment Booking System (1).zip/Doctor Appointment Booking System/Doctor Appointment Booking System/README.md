# Flutter-Doctor-Appointment-App-With-Laravel
This is about building a Doctor Appointment App with using Laravel as Backed and Dashboard. The main idea of this app is allow users to make an appointment with the doctors using mobile app. And, the major features will be demonstrated in the following videos in this series, such as Laravel Dashboard, make appointment with registered doctor, view doctor's details, rating and feedback submission and etc.

# Preview

https://youtu.be/rHjtCei-mUs

# Install

<strong>1. doc_app_Laravel - </strong><br/>
  i. Download the doc_app_Laravel file, and add in your .env file, then configure your database name and password.
  ii. Command 'php artisan migrate' at your terminal
  
<strong>2. doctor_appointment_app - </strong><br/>
  i. Download the doctor_appointment_app file, and run it on iOS simulator / Android emulator

Or refer to the demo video listed below

# Youtube Videos

Youtube Playlist : https://www.youtube.com/watch?v=G2vfT9cFENQ&list=PLU6Jd5r98RCnwTpGjREBhAtASx6Cem_EZ
